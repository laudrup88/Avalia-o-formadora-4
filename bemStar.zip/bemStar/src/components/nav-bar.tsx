import { DoorOpen, List, UserRound, UsersRound } from "lucide-react";
import React from "react";

export default function NavBar() {
  return (
    <>
      <div className="w-full h-[10%] bg-black flex justify-around items-center">
        <button
          onClick={() => (location.href = "/home")}
          className="w-[50px] h-[50px] rounded-full bg-black flex items-center justify-center"
        >
          <List className="stroke-white" />
        </button>
        <button
          onClick={() => (location.href = "/integrantes")}
          className="w-[50px] h-[50px] rounded-full bg-black flex items-center justify-center"
        >
          <UsersRound className="stroke-white" />
        </button>
        <button
          onClick={() => {
            sessionStorage.clear();
            location.href = "/";
          }}
          className="w-[50px] h-[50px] rounded-full bg-black flex items-center justify-center"
        >
          <DoorOpen className="stroke-white" />
        </button>
      </div>
    </>
  );
}
