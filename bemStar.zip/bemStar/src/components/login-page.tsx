import {
  IonAlert,
  IonButton,
  IonCol,
  IonGrid,
  IonInput,
  IonRow,
  IonText,
  IonButtons,
  IonHeader,
  IonContent,
  IonToolbar,
  IonTitle,
  IonPage,
  IonItem,
  useIonModal,
  IonModal,
  IonLabel,
  IonList,
} from "@ionic/react";
import { OverlayEventDetail } from "@ionic/react/dist/types/components/react-component-lib/interfaces";
import {
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
} from "firebase/auth";
import { useForm } from "react-hook-form";
import React, { useRef } from "react";
import { authFire, bancoFire } from "../libs/firebase";
import { get, ref, set } from "firebase/database";
import { useAtom } from "jotai/react";
import {
  stateAlertGlobal,
  stateAlertMensagemGlobal,
  stateAlertTituloGlobal,
} from "../libs/globalstate";

export const LoginPage = {
  Root: LoginPageRoot,
};

function LoginPageRoot() {
  const [_, setState] = useAtom(stateAlertGlobal);
  const [___, setMensagem] = useAtom(stateAlertMensagemGlobal);
  const [__, setTitulo] = useAtom(stateAlertTituloGlobal);
  const { handleSubmit } = useForm();
  const email = useRef<HTMLIonInputElement>(null);
  const senha = useRef<HTMLIonInputElement>(null);

  const singIng = async (data: any) => {
    if (
      typeof email.current?.value === "string" &&
      typeof senha.current?.value === "string"
    ) {
      signInWithEmailAndPassword(
        authFire,
        email.current?.value,
        senha.current?.value,
      )
        .then(async (userCredential) => {
          const user: any = userCredential.user;
          const snapshot = await get(ref(bancoFire, `dados/${user?.uid}`));

          sessionStorage.setItem("token-mobile", user.accessToken);
          sessionStorage.setItem("user-mobile", JSON.stringify(user));
          sessionStorage.setItem("user-mobile", user.uid);
          sessionStorage.setItem("user", JSON.stringify(snapshot.val()));
          if (localStorage.getItem(user.uid)) {
            location.href = "/home";
          } else {
            localStorage.setItem(user.uid, JSON.stringify([]));
            location.href = "/home";
          }
        })
        .catch((error) => {
          setState(true);
          setMensagem("Email ou senha estão incorretos!");
          setTitulo("Erro ao efetuar o login!");
        });
    }
  };

  return (
    <>
      <IonGrid class="w-[85%] h-[80%]  rounded-2xl p-10 absolute top-[50%] left-[50%] -translate-x-[50%] -translate-y-[50%] ">
        <IonRow className="">
          <IonCol className="flex items-center justify-center">
            <img className="w-[200px]" src="./assets/logo.png" alt="" />
          </IonCol>
        </IonRow>
        <form method="POST" onSubmit={handleSubmit(singIng)}>
          <IonRow class="">
            <IonCol>
              <IonInput
                ref={email}
                label="E-mail"
                name="email"
                labelPlacement="stacked"
                inputmode="email"
                color="success"
              />
              <IonInput
                ref={senha}
                label="Senha"
                name="senha"
                labelPlacement="stacked"
                type="password"
                color="success"
              />
            </IonCol>
          </IonRow>
          <IonRow>
            <IonCol class="justify-center flex">
              <IonButton id="open-cadastro" className="w-full h-[50px]">
                Cadastrar
              </IonButton>
            </IonCol>
            <IonCol class="justify-center flex">
              <IonButton type="submit" className="w-full">
                Entrar
              </IonButton>
            </IonCol>
            <IonCol class="justify-center flex">
              <IonButton id="open-modal" className="min-w-[200px]">
                Esqueceu a senha?
              </IonButton>
            </IonCol>
          </IonRow>
        </form>
      </IonGrid>
      <ModalExample />
      <ModalCadastro />
    </>
  );
}

function ModalExample() {
  const modal = useRef<HTMLIonModalElement>(null);
  const input = useRef<HTMLIonInputElement>(null);
  const [_, setState] = useAtom(stateAlertGlobal);
  const [___, setMensagem] = useAtom(stateAlertMensagemGlobal);
  const [__, setTitulo] = useAtom(stateAlertTituloGlobal);

  function confirm() {
    if (typeof input.current?.value === "string") {
      sendPasswordResetEmail(authFire, input.current?.value)
        .then(() => {
          setState(true);
          setMensagem(
            "Foi enviado um link de redefinição de senha para o seu e-mail",
          );
          setTitulo("Redefinir senha");
          modal.current?.dismiss(input.current?.value, "confirm");
        })
        .catch((error) => {
          setState(true);
          setMensagem(
            "Erro ao tentar enviar o link de redefinição de senha para este e-mail",
          );
          setTitulo("Redefinir senha");
        });
    }
  }

  function onWillDismiss(ev?: CustomEvent<OverlayEventDetail>) {
    if (ev?.detail.role === "confirm") {
      console.log();
    }
  }

  return (
    <IonModal
      ref={modal}
      trigger="open-modal"
      onWillDismiss={(ev) => onWillDismiss(ev)}
    >
      <IonHeader>
        <IonToolbar>
          <h3 className="ml-5">Redefinir senha</h3>
          <IonButtons slot="end">
            <IonButton onClick={() => modal.current?.dismiss()}>
              Cancelar
            </IonButton>
            <IonButton strong={true} onClick={() => confirm()}>
              Confirmar
            </IonButton>
          </IonButtons>
        </IonToolbar>
      </IonHeader>
      <IonContent className="ion-padding">
        <IonItem>
          <IonInput
            label="Seu e-mail"
            labelPlacement="stacked"
            ref={input}
            type="email"
            placeholder="exemplo@email.com"
          />
        </IonItem>
      </IonContent>
    </IonModal>
  );
}

interface userCadastro {
  uid: string;
  nomeCompleto: string;
  dataNascimento: string;
  email: string;
}
function ModalCadastro() {
  const modal = useRef<HTMLIonModalElement>(null);
  const email = useRef<HTMLIonInputElement>(null);
  const senha = useRef<HTMLIonInputElement>(null);
  const { register, handleSubmit } = useForm();
  const [_, setState] = useAtom(stateAlertGlobal);
  const [___, setMensagem] = useAtom(stateAlertMensagemGlobal);
  const [__, setTitulo] = useAtom(stateAlertTituloGlobal);

  const confirm = async (data: any) => {
    if (
      typeof email.current?.value === "string" &&
      typeof senha.current?.value === "string"
    ) {
      if ((await verifyIntegridade(data)) === false) {
        return;
      }
      createUserWithEmailAndPassword(
        authFire,
        email.current?.value,
        senha.current?.value,
      )
        .then(async (userCredential: any) => {
          const user = userCredential.user;
          set(ref(bancoFire, "dados/" + user.uid), {
            uid: user.uid,
            nomeCompleto: data?.nomeCompleto,
            dataNascimento: data?.dataNascimento,
            email: email.current?.value,
          });
          setState(true);
          setMensagem("");
          setTitulo("Cadastrado com sucesso!");
          modal.current?.dismiss("confirm");
        })
        .catch((error) => {
          setState(true);
          setMensagem("Este e-mail já está cadastrado!");
          setTitulo("Erro ao se cadastrar");
        });
    }
  };

  function onWillDismiss(ev: CustomEvent<OverlayEventDetail>) {
    if (ev.detail.role === "confirm") {
      console.log();
    }
  }

  const verifyIntegridade = async (data: any) => {
    const { comSenha, nomeCompleto, dataNascimento } = data;
    if (!nomeCompleto) {
      setState(true);
      setMensagem("Preencha todos os campos");
      setTitulo("Erro");
      return false;
    }
    if (senha.current?.value !== comSenha) {
      setState(true);
      setMensagem("Senhas diferentes");
      setTitulo("Erro ao se cadastrar");
      return false;
    }
    return true;
  };

  return (
    <IonModal
      ref={modal}
      trigger="open-cadastro"
      onWillDismiss={(ev) => onWillDismiss(ev)}
    >
      <IonHeader>
        <IonToolbar>
          <IonTitle>Cadastrar</IonTitle>
          <IonButtons slot="end">
            <IonButton onClick={() => modal.current?.dismiss()}>
              Cancelar
            </IonButton>
          </IonButtons>
        </IonToolbar>
      </IonHeader>
      <IonContent className="ion-padding">
        <form onSubmit={handleSubmit(confirm)} className="flex flex-col gap-3">
          <IonList>
            <IonItem>
              <IonInput
                {...register("nomeCompleto")}
                id="nomeCompleto"
                name="nomeCompleto"
                label="Nome completo"
                required
                labelPlacement="fixed"
              />
            </IonItem>
            <IonItem>
              <IonInput
                {...register("dataNascimento")}
                id="dataNascimento"
                type="date"
                name="dataNascimento"
                label="Data de nascimento"
                required
                labelPlacement="fixed"
              ></IonInput>
            </IonItem>
            <IonItem>
              <IonInput
                ref={email}
                id="email"
                type="email"
                name="email"
                label="E-mail"
                required
                labelPlacement="fixed"
              ></IonInput>
            </IonItem>
            <IonItem>
              <IonInput
                ref={senha}
                id="senha"
                type="password"
                name="senha"
                label="Senha"
                autocomplete="email"
                required
                labelPlacement="fixed"
              />
            </IonItem>
            <IonItem>
              <IonInput
                {...register("comSenha")}
                id="comSenha"
                type="password"
                name="comSenha"
                label="Confirmar senha"
                required
                labelPlacement="fixed"
              />
            </IonItem>
          </IonList>
          <IonButton type="submit">Cadastrar</IonButton>
        </form>
      </IonContent>
    </IonModal>
  );
}
