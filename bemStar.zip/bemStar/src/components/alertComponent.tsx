import { IonAlert } from "@ionic/react";
import { useAtom, useAtomValue } from "jotai/react";
import React from "react";
import { stateAlertGlobal, stateAlertMensagemGlobal, stateAlertTituloGlobal } from "../libs/globalstate";


export default function AlertComponent() {
  const [state, setState] = useAtom(stateAlertGlobal);
  const mensagem = useAtomValue(stateAlertMensagemGlobal);
  const titulo = useAtomValue(stateAlertTituloGlobal);

  return (
    <IonAlert
      isOpen={state}
      header={titulo}
      message={mensagem}
      buttons={["Voltar"]}
      onDidDismiss={() => setState(false)}
    ></IonAlert>
  );
}
