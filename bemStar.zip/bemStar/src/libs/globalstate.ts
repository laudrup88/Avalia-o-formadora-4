import { atomWithStorage } from "jotai/utils";
import { atom } from "jotai/vanilla";

export type itemHumor = {
  img: "";
  data: string;
  humor: string;
  descricao: string;
};

export const stateAlertGlobal = atom(false);
export const stateAlertMensagemGlobal = atom("");
export const stateAlertTituloGlobal = atom("");
export const stateModal = atom(false);
export const itemSelectGLobal = atom<itemHumor | null>(null);