// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getDatabase } from "firebase/database";

const firebaseConfig = {
  apiKey: "AIzaSyAPKJY5fCL7hDxCs0JkbiLo3gmhLZLAuds",
  authDomain: "bem-estar-dcca7.firebaseapp.com",
  projectId: "bem-estar-dcca7",
  storageBucket: "bem-estar-dcca7.appspot.com",
  messagingSenderId: "407932163995",
  appId: "1:407932163995:web:e3b1c1373795d72a16333e",
  measurementId: "G-7EJPDKYW7N"
};


const app = initializeApp(firebaseConfig);
export const authFire = getAuth(app);
export const bancoFire = getDatabase(app);