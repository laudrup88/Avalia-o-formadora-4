import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.bemStar',
  appName: 'Bem Estar',
  webDir: 'build'
};

export default config;
