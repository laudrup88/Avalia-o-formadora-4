import React, { useEffect, useRef, useState } from "react";
import { Plus } from "lucide-react";
import {
  IonButton,
  IonButtons,
  IonContent,
  IonHeader,
  IonImg,
  IonInput,
  IonItem,
  IonModal,
  IonSelect,
  IonSelectOption,
  IonTextarea,
  IonToolbar,
} from "@ionic/react";
import { OverlayEventDetail } from "@ionic/react/dist/types/components/react-component-lib/interfaces";
import { sendPasswordResetEmail } from "firebase/auth";
import { useAtom } from "jotai/react";
import { authFire } from "../libs/firebase";
import {
  stateAlertGlobal,
  stateAlertMensagemGlobal,
  stateAlertTituloGlobal,
} from "../libs/globalstate";
import { useForm } from "react-hook-form";
import cn from "../libs/utils";

export type itemHumor = {
  img: "";
  data: string;
  humor: string;
  descricao: string;
};

export default function ListHistoty() {
  const [listHumor, setListHumor] = useState<itemHumor[]>([]);

  useEffect(() => {
    const uid = sessionStorage.getItem("user-mobile");
    if (uid) {
      const listaItens = localStorage.getItem(uid);
      if (listaItens) {
        setListHumor(JSON.parse(listaItens));
      }
    }
  }, []);

  return (
    <>
      <div className="absolute w-[95%] h-full flex flex-col gap-2 mt-2">
        {listHumor?.map((item, i) => {
          return (
            <div
              key={i}
              className={cn(
                `w-full h-[100px] flex-none flex justify-around rounded-3xl items-center`,
                item.humor === "Muito bem" && "bg-green-400",
                item.humor === "Bem" && "bg-green-200",
                item.humor === "Neutro" && "bg-blue-400",
                item.humor === "Mal" && "bg-yellow-200",
                item.humor === "Muito Mal" && "bg-red-400",
              )}
            >
              <img src={item.img} alt="" className="w-[13.33%]" />
              <span className="w-[33.33%]">{item.humor}</span>
              <span className="w-[33.33%]">{item.data}</span>
            </div>
          );
        })}
        <IonButton
          id="open-modal"
          className={`bg-blue-400 flex items-center justify-center w-full h-[100px] flex-none rounded-3xl sticky bottom-1 gap-4 active:scale-95 transition-all shadow-md shadow-stone-400`}
        >
          <span className="text-white">Como você está se sentindo?</span>
          <Plus className="absolute stroke-white right-3 w-[30px] h-[30px]" />
        </IonButton>
        <div className={`w-full h-[100px] flex-none`}></div>
      </div>
      <ModalExample setItem={setListHumor} />
    </>
  );
}

function ModalExample({ setItem }: { setItem: any }) {
  const modal = useRef<HTMLIonModalElement>(null);
  const input = useRef<HTMLIonInputElement>(null);
  const [_, setState] = useAtom(stateAlertGlobal);
  const [___, setMensagem] = useAtom(stateAlertMensagemGlobal);
  const [__, setTitulo] = useAtom(stateAlertTituloGlobal);

  const { register, handleSubmit } = useForm();

  const [item, setItemHumor] = useState<itemHumor>();
  const [imgHumor, setImgHumor] = useState<string>(
    "https://placehold.co/200x200?text=Humor",
  );

  function confirm(data: any) {
    let img = "";
    switch (data.humor) {
      case "Muito bem":
        setImgHumor("./assets/emoji/sorrir.png");
        img = "./assets/emoji/sorrir.png";
        break;

      case "Bem":
        img = "./assets/emoji/feliz.png";
        break;
      case "Neutro":
        img = "./assets/emoji/confuso.png";
        break;
      case "Mal":
        img = "./assets/emoji/triste.png";
        break;
      case "Muito Mal":
        img = "./assets/emoji/choro.png";
        break;
    }

    const newItem = {
      data: new Date().toLocaleDateString(),
      descricao: data.descricao,
      humor: data.humor,
      img: img,
    };

    setItemHumor((prevState: any) => ({
      ...prevState,
      data: new Date().toLocaleDateString(),
      descricao: data.descricao,
      humor: data.humor,
      img: img,
    }));

    const uid = sessionStorage.getItem("user-mobile");
    if (uid) {
      const listaItens = localStorage.getItem(uid);
      if (listaItens) {
        const listaOld = JSON.parse(listaItens);
        listaOld.push(newItem);
        localStorage.setItem(uid, JSON.stringify(listaOld));
      }
    }

    setTimeout(() => {
      window.location.reload();
    }, 500);

    modal.current?.dismiss(input.current?.value, "confirm");
  }

  function onWillDismiss(ev?: CustomEvent<OverlayEventDetail>) {
    if (ev?.detail.role === "confirm") {
      console.log();
    }
  }

  return (
    <form method="POST">
      <IonModal
        ref={modal}
        trigger="open-modal"
        onWillDismiss={(ev) => onWillDismiss(ev)}
      >
        <IonHeader>
          <IonToolbar>
            <h3 className="ml-5">Selecione as opções</h3>
            <IonButtons slot="end">
              <IonButton onClick={() => modal.current?.dismiss()}>
                Cancelar
              </IonButton>
              <IonButton strong={true} onClick={handleSubmit(confirm)}>
                Confirmar
              </IonButton>
            </IonButtons>
          </IonToolbar>
        </IonHeader>
        <IonContent className="ion-padding">
          <IonItem>
            <IonSelect
              {...register("humor")}
              label="Humor"
              labelPlacement="stacked"
              placeholder="Selecione o seu humor"
            >
              <IonSelectOption value="Muito bem">Muito bem</IonSelectOption>
              <IonSelectOption value="Bem">Bem</IonSelectOption>
              <IonSelectOption value="Neutro">Neutro</IonSelectOption>
              <IonSelectOption value="Mal">Mal</IonSelectOption>
              <IonSelectOption value="Muito Mal">Muito Mal</IonSelectOption>
            </IonSelect>
          </IonItem>
          <IonItem>
            <IonTextarea
              {...register("descricao")}
              label="Descrição"
              labelPlacement="stacked"
              placeholder="Conte, o que aconteceu hoje"
              required
            />
          </IonItem>
          {/* <div className="w-full max-h-[200px] mt-2 flex items-center justify-center">
            <IonImg src={imgHumor} class="w-[200px] h-[200px]" />
          </div> */}
        </IonContent>
      </IonModal>
    </form>
  );
}
