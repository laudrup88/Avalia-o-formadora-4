import { atomWithStorage } from "jotai/utils";
import { atom } from "jotai/vanilla";


export const stateAlertGlobal = atom(false);
export const stateAlertMensagemGlobal = atom("");
export const stateAlertTituloGlobal = atom("");

