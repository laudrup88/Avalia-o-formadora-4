// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getDatabase } from "firebase/database";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAXuUJxZeP21UrX4VGm4AW8F1F136G4MTA",
  authDomain: "bemstar-37f51.firebaseapp.com",
  projectId: "bemstar-37f51",
  storageBucket: "bemstar-37f51.appspot.com",
  messagingSenderId: "722285147461",
  appId: "1:722285147461:web:2213b674ce94c4f2067a2c"
};

const app = initializeApp(firebaseConfig);
export const authFire = getAuth(app);
export const bancoFire = getDatabase(app);