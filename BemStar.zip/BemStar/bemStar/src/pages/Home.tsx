import React, { useEffect } from "react";
import ListHistoty from "../components/list-history";
import NavBar from "../components/nav-bar";

export default function Home() {

  return (
    <>
      <div className="h-screen w-screen">
        <div className="w-full h-[90%] relative overflow-auto flex justify-center">
          <ListHistoty />
        </div>
        <NavBar />
      </div>
    </>
  );
}
