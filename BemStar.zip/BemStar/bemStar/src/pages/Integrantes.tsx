import React from "react";
import NavBar from "../components/nav-bar";

export default function Integrantes() {
  return (
    <>
      <div className="w-screen h-screen ">
        <div className="w-full h-[90%] relative overflow-auto flex justify-center">
          <div className="absolute w-[95%] h-full flex flex-col gap-2 mt-5">
            <div className="flex items-center justify-around gap-2 bg-amber-300 p-5 rounded-md">
              <img className="w-[60px]" src="./assets/Bryan.jpg" alt="" />
              <div className="flex flex-col text-sm min-w-[300px]">
                <span>Nome: Bryan Ferreira de Almeida</span>
                <span>Turma: ADS0303N</span>
              </div>
            </div>
            <div className="flex items-center justify-around gap-2 bg-amber-300 p-5 rounded-md">
              <img className="w-[70px]" src="./assets/Manu.jpg" alt="" />
              <div className="flex flex-col text-sm min-w-[300px]">
                <span>Nome: <br />Emanuelle Christine Santana Barboza</span>
                <span>Turma: ADS0303N</span>
              </div>
            </div>
          </div>
        </div>
        <NavBar />
      </div>
    </>
  );
}
