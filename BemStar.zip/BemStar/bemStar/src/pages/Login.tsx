import React from "react";
import { LoginPage } from "../components/login-page";

const Login: React.FC = () => {
  return (
    <>
      <LoginPage.Root />
    </>
  );
};

export default Login;
