import React, { useState } from "react";
import {
  IonApp,
  IonContent,
  IonHeader,
  IonTitle,
  IonToolbar,
  IonInput,
  IonItem,
  IonLabel,
  IonButton,
  IonPage,
  IonList,
} from "@ionic/react";

const Cadastro: React.FC = () => {
  const [nome, setNome] = useState("");
  const [dataNascimento, setDataNascimento] = useState("");
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [confirmarSenha, setConfirmarSenha] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Verificação de senha
    if (senha !== confirmarSenha) {
      alert("As senhas não coincidem!");
      return;
    }

    // Verificação de tamanho dos campos
    if (nome.length > 50) {
      alert("O nome não pode ter mais de 50 caracteres!");
      return;
    }

    if (senha.length < 6) {
      alert("A senha deve ter no mínimo 6 caracteres!");
      return;
    }

    // Aqui você pode adicionar a lógica para enviar os dados para o servidor
    alert("Cadastro realizado com sucesso!");
  };

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Cadastro</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent className="ion-padding">
        <form onSubmit={handleSubmit}>
          <IonList>
            <IonItem>
              <IonLabel position="floating">Nome</IonLabel>
              <IonInput
                value={nome}
                onIonChange={(e) => setNome(e.detail.value!)}
                maxlength={50}
                required
              />
            </IonItem>
            <IonItem>
              <IonLabel position="floating">Data de Nascimento</IonLabel>
              <IonInput
                type="date"
                value={dataNascimento}
                onIonChange={(e) => setDataNascimento(e.detail.value!)}
                required
              />
            </IonItem>
            <IonItem>
              <IonLabel position="floating">Email</IonLabel>
              <IonInput
                type="email"
                value={email}
                onIonChange={(e) => setEmail(e.detail.value!)}
                required
              />
            </IonItem>
            <IonItem>
              <IonLabel position="floating">Senha</IonLabel>
              <IonInput
                type="password"
                value={senha}
                onIonChange={(e) => setSenha(e.detail.value!)}
                minlength={6}
                required
              />
            </IonItem>
            <IonItem>
              <IonLabel position="floating">Confirmar Senha</IonLabel>
              <IonInput
                type="password"
                value={confirmarSenha}
                onIonChange={(e) => setConfirmarSenha(e.detail.value!)}
                minlength={6}
                required
              />
            </IonItem>
          </IonList>
          <IonButton expand="block" type="submit">
            Cadastrar
          </IonButton>
        </form>
      </IonContent>
    </IonPage>
  );
};

export default Cadastro;
