/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./**/**/*.{html,jsx,tsx}"],
  theme: {
    extend: {},
  },
  plugins: [],
};
