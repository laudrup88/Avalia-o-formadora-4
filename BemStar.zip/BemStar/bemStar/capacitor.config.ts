import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.bemStar',
  appName: 'bemStar',
  webDir: 'build'
};

export default config;
